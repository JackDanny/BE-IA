Le BE est s�par� en deux partie:

	La premi�re partie, initiation � PLNE avec scip dans le r�pertoire scip

	La deuxi�me partie, contenant la partie weka

Chacune de ces parties contient plusieurs r�pertoires contenant du code ou des fichiers texte r�sultat.
Il y a un rapport pour chacune des deux parties (fichier pdf ou/et docx)
Dans les rapports sont indiqu�s les r�pertoires o� se trouvent les diff�rents fichiers concern�s.



Daniel VEYSSEIRE

